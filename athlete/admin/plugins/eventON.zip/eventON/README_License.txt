A valid EventON license purchased via codecanyon.net is permitted to be installed and activated in wordpress site running on one domain only. Additional licenses must be purchased to use eventON on different domains.

== Developer license notice ==
Purchasing extended license of EventON DO NOT give you permission to include eventON in a product that will be resold in envato marketplace or any other marketplace. A written (email) permission must be required from us (EventON team) in order to use eventON in a resellable product.