<?php

/*
 * @package Courses Manager
 * @version 1.0.0
 * @created Mar 20, 2015
 * @author Inwavethemes
 * @email inwavethemes@gmail.com
 * @website http://inwavethemes.com
 * @support Ticket https://inwave.ticksy.com/
 * @copyright Copyright (c) 2015 Inwavethemes. All rights reserved.
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 *
 */

/**
 * Description of taxonomy-iw_courses-class
 *
 * @developer duongca
 */
iw_course_get_template_part('taxonomy');